<?php
return [

    
    // name','email','mobile','message_title','message_body','reply'

        'admin' => [
            'system' => [
                'custom_ship_one' => 'Custom Shipping One',
                'custom_ship_two' => 'Custom Shipping Two'
            ]
        ]


];